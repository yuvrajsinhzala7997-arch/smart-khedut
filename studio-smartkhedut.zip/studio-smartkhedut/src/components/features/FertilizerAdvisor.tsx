"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { aiFertilizerAdvisor, type AIFertilizerAdvisorOutput } from "@/ai/flows/ai-fertilizer-advisor"
import { Loader2, FlaskConical, Calendar, ShoppingCart, Weight } from "lucide-react"

export function FertilizerAdvisor() {
  const [crop, setCrop] = useState("")
  const [loading, setLoading] = useState(false)
  const [advice, setAdvice] = useState<AIFertilizerAdvisorOutput | null>(null)

  const handleGetAdvice = async () => {
    if (!crop) return
    setLoading(true)
    try {
      const result = await aiFertilizerAdvisor({ cropName: crop })
      setAdvice(result)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-2xl flex items-center gap-2">
          <FlaskConical className="w-6 h-6 text-primary" />
          ખાતર સલાહકાર
        </CardTitle>
        <CardDescription>ખાતરની યોગ્ય સલાહ મેળવવા માટે તમારા પાકનું નામ લખો</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex gap-2">
          <Input 
            placeholder="દા.ત. ઘઉં, કપાસ, ડાંગર..." 
            value={crop}
            onChange={(e) => setCrop(e.target.value)}
            className="text-lg py-6"
          />
          <Button onClick={handleGetAdvice} disabled={loading} className="py-6 px-8">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "સલાહ મેળવો"}
          </Button>
        </div>

        {advice && (
          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-bold text-lg text-primary">{advice.fertilizerName}</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-secondary rounded-lg flex items-center gap-3">
                <Weight className="w-5 h-5 text-primary" />
                <div>
                  <div className="text-xs text-muted-foreground">જથ્થો</div>
                  <div className="font-bold">{advice.quantityPerAcre}</div>
                </div>
              </div>
              <div className="p-3 bg-secondary rounded-lg flex items-center gap-3">
                <Calendar className="w-5 h-5 text-primary" />
                <div>
                  <div className="text-xs text-muted-foreground">સમય</div>
                  <div className="font-bold">{advice.applicationTime}</div>
                </div>
              </div>
              <div className="p-3 bg-secondary rounded-lg flex items-center gap-3">
                <ShoppingCart className="w-5 h-5 text-primary" />
                <div>
                  <div className="text-xs text-muted-foreground">અંદાજિત કિંમત</div>
                  <div className="font-bold">{advice.estimatedCost}</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
