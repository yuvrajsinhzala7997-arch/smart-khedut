"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Calculator, IndianRupee, PieChart, Wallet } from "lucide-react"

export function ProfitCalculator() {
  const [land, setLand] = useState(1)
  const [costSeed, setCostSeed] = useState(2000)
  const [costFert, setCostFert] = useState(3000)
  const [costPest, setCostPest] = useState(1500)
  const [expectedIncome, setExpectedIncome] = useState(25000)

  const totalCost = (costSeed + costFert + costPest) * land
  const totalIncome = expectedIncome * land
  const netProfit = totalIncome - totalCost
  const profitMargin = totalIncome > 0 ? (netProfit / totalIncome) * 100 : 0

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-2xl flex items-center gap-2">
          <Calculator className="w-6 h-6 text-primary" />
          નફાનું કેલ્ક્યુલેટર
        </CardTitle>
        <CardDescription>એકર દીઠ તમારા ખર્ચ અને કમાણીનો અંદાજ લગાવો</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>જમીનનું કદ (એકર)</Label>
            <Input type="number" value={land} onChange={(e) => setLand(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label>એકર દીઠ અપેક્ષિત આવક (₹)</Label>
            <Input type="number" value={expectedIncome} onChange={(e) => setExpectedIncome(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label>એકર દીઠ બિયારણનો ખર્ચ (₹)</Label>
            <Input type="number" value={costSeed} onChange={(e) => setCostSeed(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label>એકર દીઠ ખાતરનો ખર્ચ (₹)</Label>
            <Input type="number" value={costFert} onChange={(e) => setCostFert(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label>એકર દીઠ જંતુનાશકનો ખર્ચ (₹)</Label>
            <Input type="number" value={costPest} onChange={(e) => setCostPest(Number(e.target.value))} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
          <div className="p-4 bg-red-50 rounded-lg text-center border border-red-100">
            <div className="text-xs text-red-600 font-bold uppercase mb-1">કુલ ખર્ચ</div>
            <div className="text-2xl font-black text-red-700">₹ {totalCost.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-blue-50 rounded-lg text-center border border-blue-100">
             <div className="text-xs text-blue-600 font-bold uppercase mb-1">કુલ આવક</div>
            <div className="text-2xl font-black text-blue-700">₹ {totalIncome.toLocaleString()}</div>
          </div>
          <div className="p-4 bg-green-50 rounded-lg text-center border border-green-100">
             <div className="text-xs text-green-600 font-bold uppercase mb-1">ચોખ્ખો નફો</div>
            <div className="text-2xl font-black text-green-700">₹ {netProfit.toLocaleString()}</div>
          </div>
        </div>

        <div className="bg-primary/10 p-4 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <PieChart className="w-8 h-8 text-primary" />
            <div>
              <div className="text-sm font-bold text-primary">નફાનો ગાળો (માર્જિન)</div>
              <div className="text-xs text-muted-foreground">તમારી ખેતીની કાર્યક્ષમતા</div>
            </div>
          </div>
          <div className="text-3xl font-black text-primary">{profitMargin.toFixed(1)}%</div>
        </div>
      </CardContent>
    </Card>
  )
}
