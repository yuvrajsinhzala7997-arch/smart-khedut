"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { aiCropRecommendation, type AiCropRecommendationOutput } from "@/ai/flows/ai-crop-recommendation-flow"
import { Loader2, Sprout, TrendingUp, Landmark } from "lucide-react"

const formSchema = z.object({
  soilType: z.string().min(1, "Required"),
  season: z.string().min(1, "Required"),
  state: z.string().min(1, "Required"),
  landSizeAcres: z.string().transform((v) => parseFloat(v) || 0),
})

export function CropRecommendation() {
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<AiCropRecommendationOutput | null>(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      soilType: "",
      season: "",
      state: "",
      landSizeAcres: 1 as any,
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoading(true)
    try {
      const output = await aiCropRecommendation({
        soilType: values.soilType,
        season: values.season,
        state: values.state,
        landSizeAcres: values.landSizeAcres,
      })
      setResults(output)
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center gap-2">
            <Sprout className="w-6 h-6 text-primary" />
            AI પાક ભલામણ
          </CardTitle>
          <CardDescription>શ્રેષ્ઠ પાક સૂચનો મેળવવા માટે ખેતરની વિગતો દાખલ કરો</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="soilType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>જમીનનો પ્રકાર</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="જમીન પસંદ કરો" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="loamy">ગોરાડુ (Loamy)</SelectItem>
                          <SelectItem value="sandy">રેતાળ (Sandy)</SelectItem>
                          <SelectItem value="clay">ચીકણી (Clay)</SelectItem>
                          <SelectItem value="black">કાળી જમીન (Black)</SelectItem>
                          <SelectItem value="red">લાલ જમીન (Red)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="season"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ઋતુ</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="ઋતુ પસંદ કરો" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Kharif">ખરીફ (ચોમાસું)</SelectItem>
                          <SelectItem value="Rabi">રવિ (શિયાળુ)</SelectItem>
                          <SelectItem value="Summer">ઉનાળુ</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>રાજ્ય</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="રાજ્ય પસંદ કરો" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Gujarat">ગુજરાત</SelectItem>
                          <SelectItem value="Maharashtra">મહારાષ્ટ્ર</SelectItem>
                          <SelectItem value="Punjab">પંજાબ</SelectItem>
                          <SelectItem value="Rajasthan">રાજસ્થાન</SelectItem>
                          <SelectItem value="Uttar Pradesh">ઉત્તર પ્રદેશ</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="landSizeAcres"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>જમીનનું કદ (એકર)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.5" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Button type="submit" className="w-full py-6 text-lg font-bold" disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "ભલામણો મેળવો"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {results && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {results.recommendedCrops.map((crop, idx) => (
            <Card key={idx} className="border-l-4 border-primary">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl font-headline flex items-center justify-between">
                  {crop.cropName}
                  <TrendingUp className="w-5 h-5 text-primary" />
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center text-sm p-2 rounded bg-muted">
                  <span className="text-muted-foreground">અપેક્ષિત ઉપજ:</span>
                  <span className="font-bold">{crop.expectedYieldKgPerAcre} કિલો/એકર</span>
                </div>
                <div className="flex justify-between items-center text-sm p-2 rounded bg-primary/10">
                  <span className="text-muted-foreground">અંદાજિત નફો:</span>
                  <span className="font-bold text-primary">₹ {crop.estimatedProfitPerAcreINR}</span>
                </div>
                <p className="text-sm italic text-muted-foreground">{crop.reasoning}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
