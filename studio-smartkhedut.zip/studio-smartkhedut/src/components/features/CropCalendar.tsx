"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Calendar as CalendarIcon, Droplets, Scissors, FlaskConical, Sprout } from "lucide-react"

const TIMELINE = [
  { phase: "વાવણી", date: "૧૫ ઓક્ટોબર - ૧૫ નવેમ્બર", icon: Sprout, color: "text-green-600", bg: "bg-green-100" },
  { phase: "૧ લુ પિયત", date: "૦૫ ડિસેમ્બર", icon: Droplets, color: "text-blue-600", bg: "bg-blue-100" },
  { phase: "ખાતરનો ડોઝ", date: "૨૦ ડિસેમ્બર", icon: FlaskConical, color: "text-purple-600", bg: "bg-purple-100" },
  { phase: "૨ જુ પિયત", date: "૧૦ જાન્યુઆરી", icon: Droplets, color: "text-blue-600", bg: "bg-blue-100" },
  { phase: "કાપણી", date: "૨૦ માર્ચ - ૧૦ એપ્રિલ", icon: Scissors, color: "text-orange-600", bg: "bg-orange-100" },
]

export function CropCalendar() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-2xl flex items-center gap-2">
          <CalendarIcon className="w-6 h-6 text-primary" />
          ઘઉંના પાકનું સમયપત્રક
        </CardTitle>
        <CardDescription>રવિ સીઝન માટે આયોજિત ખેતી પ્રવૃત્તિઓ</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="relative space-y-4">
          <div className="absolute left-6 top-2 bottom-2 w-0.5 bg-muted hidden sm:block" />
          {TIMELINE.map((item, idx) => (
            <div key={idx} className="flex flex-col sm:flex-row sm:items-center gap-4 relative">
              <div className={`w-12 h-12 ${item.bg} rounded-full flex items-center justify-center shrink-0 z-10 border-4 border-white shadow-sm`}>
                <item.icon className={`w-6 h-6 ${item.color}`} />
              </div>
              <div className="flex-1 p-3 bg-muted/30 rounded-lg border border-muted/50">
                <h4 className="font-bold">{item.phase}</h4>
                <p className="text-sm text-muted-foreground">{item.date}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
