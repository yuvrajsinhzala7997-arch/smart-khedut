"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { CircleDollarSign, ArrowUp, ArrowDown } from "lucide-react"
import { useLanguage } from "@/context/LanguageContext"

const PRICES_DATA = {
  en: [
    { crop: "Wheat (Grade A)", mandi: "Khanna, Punjab", price: 2350, change: "+1.2%" },
    { crop: "Rice (Basmati)", mandi: "Karnal, Haryana", price: 3400, change: "-0.5%" },
    { crop: "Cotton", mandi: "Gondal, Gujarat", price: 6800, change: "+2.4%" },
    { crop: "Groundnut", mandi: "Rajkot, Gujarat", price: 5900, change: "+0.8%" },
    { crop: "Onion", mandi: "Lasalgaon, Maharashtra", price: 1800, change: "-3.1%" },
  ],
  hi: [
    { crop: "गेहूं (ग्रेड ए)", mandi: "खन्ना, पंजाब", price: 2350, change: "+1.2%" },
    { crop: "चावल (बासमती)", mandi: "करनाल, हरियाणा", price: 3400, change: "-0.5%" },
    { crop: "कपास", mandi: "गोंडल, गुजरात", price: 6800, change: "+2.4%" },
    { crop: "मूंगफली", mandi: "राजकोट, गुजरात", price: 5900, change: "+0.8%" },
    { crop: "प्याज", mandi: "लासलगांव, महाराष्ट्र", price: 1800, change: "-3.1%" },
  ],
  gu: [
    { crop: "ઘઉં (ગ્રેડ એ)", mandi: "ખન્ના, પંજાબ", price: 2350, change: "+1.2%" },
    { crop: "ચોખા (બાસમતી)", mandi: "કરનાલ, હરિયાણા", price: 3400, change: "-0.5%" },
    { crop: "કપાસ", mandi: "ગોંડલ, ગુજરાત", price: 6800, change: "+2.4%" },
    { crop: "મગફળી", mandi: "રાજકોટ, ગુજરાત", price: 5900, change: "+0.8%" },
    { crop: "ડુંગળી", mandi: "લાસલગાંવ, મહારાષ્ટ્ર", price: 1800, change: "-3.1%" },
  ]
}

export function MandiPrices() {
  const { t, language } = useLanguage()
  const prices = (PRICES_DATA as any)[language]

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="font-headline text-2xl flex items-center gap-2">
          <CircleDollarSign className="w-6 h-6 text-primary" />
          {t('current_mandi_prices')}
        </CardTitle>
        <Badge variant="outline">{t('live_update')}</Badge>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t('crop_col')}</TableHead>
              <TableHead>{t('mandi_col')}</TableHead>
              <TableHead>{t('price_col')}</TableHead>
              <TableHead>{t('trend_col')}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {prices.map((item: any, idx: number) => (
              <TableRow key={idx}>
                <TableCell className="font-medium">{item.crop}</TableCell>
                <TableCell className="text-muted-foreground text-xs">{item.mandi}</TableCell>
                <TableCell className="font-bold">₹ {item.price}</TableCell>
                <TableCell>
                  <span className={`flex items-center gap-1 text-xs font-bold ${item.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                    {item.change.startsWith('+') ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                    {item.change}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
