"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Landmark, ArrowRight, BookOpen } from "lucide-react"

const SCHEMES = [
  {
    title: "પીએમ-કિસાન સન્માન નિધિ",
    description: "તમામ ખેતી ધરાવતા ખેડૂત પરિવારોને વાર્ષિક ₹૬,૦૦૦ ની આવક સહાય ત્રણ સમાન હપ્તામાં મળે છે.",
    category: "આવક સહાય",
    date: "ચાલુ છે"
  },
  {
    title: "પ્રધાનમંત્રી ફસલ વીમા યોજના (PMFBY)",
    description: "કુદરતી આફતોથી થતા પાકના નુકસાનના જોખમને ઘટાડવા માટે વ્યાપક પાક વીમો પૂરો પાડે છે.",
    category: "વીમો",
    date: "નોંધણી ચાલુ"
  },
  {
    title: "સોઈલ હેલ્થ કાર્ડ યોજના",
    description: "ખેડૂતોને તેમની જમીનમાં પોષક તત્વોની ઉણપ સમજવામાં મદદ કરવા માટે મફત જમીન પરીક્ષણ.",
    category: "જમીન સ્વાસ્થ્ય",
    date: "ઓનલાઇન અરજી"
  },
  {
    title: "કિસાન ક્રેડિટ કાર્ડ (KCC)",
    description: "ઓછા વ્યાજ દરે ખેતીની જરૂરિયાતો માટે સમયસર લોન અને ધિરાણની સુવિધા.",
    category: "લોન/ધિરાણ",
    date: "ખુલ્લું છે"
  }
]

export function GovSchemes() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-headline font-bold flex items-center gap-2">
          <Landmark className="w-6 h-6 text-primary" />
          સરકારી યોજનાઓ
        </h2>
        <Button variant="ghost" size="sm" className="gap-1">બધી જુઓ <ArrowRight className="w-4 h-4" /></Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SCHEMES.map((scheme, idx) => (
          <Card key={idx} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <Badge variant="secondary" className="mb-2">{scheme.category}</Badge>
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">{scheme.date}</Badge>
              </div>
              <CardTitle className="text-lg">{scheme.title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground line-clamp-2">{scheme.description}</p>
              <Button variant="outline" size="sm" className="w-full gap-2">
                <BookOpen className="w-4 h-4" />
                વિગતો વાંચો
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
