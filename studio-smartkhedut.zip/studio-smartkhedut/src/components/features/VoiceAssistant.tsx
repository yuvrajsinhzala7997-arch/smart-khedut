"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Mic, Square, Loader2, Volume2, Bot } from "lucide-react"
import { aiVoiceAssistant } from "@/ai/flows/ai-voice-assistant-flow"
import { Textarea } from "@/components/ui/textarea"

export function VoiceAssistant() {
  const [query, setQuery] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [loading, setLoading] = useState(false)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const handleSend = async () => {
    if (!query) return
    setLoading(true)
    try {
      const response = await aiVoiceAssistant(query)
      setAudioUrl(response.media)
      // Auto-play the audio
      if (audioRef.current) {
        audioRef.current.load()
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const toggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true)
      // Simulation: After 2 seconds, stop recording and set a query
      setTimeout(() => {
        setIsRecording(false)
        setQuery("ઘઉંના વાવેતર માટે કયો સમય ઉત્તમ છે?")
      }, 2500)
    } else {
      setIsRecording(false)
    }
  }

  return (
    <Card className="border-accent bg-accent/5">
      <CardHeader>
        <CardTitle className="font-headline text-2xl flex items-center gap-2">
          <Bot className="w-6 h-6 text-accent-foreground" />
          સ્માર્ટ ખેડૂત વોઇસ આસિસ્ટન્ટ
        </CardTitle>
        <CardDescription>ગુજરાતી, હિન્દી અથવા અંગ્રેજીમાં પ્રશ્નો પૂછો</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="relative">
          <Textarea 
            placeholder="તમારો પ્રશ્ન અહીં લખો અથવા માઇક્રોફોનનો ઉપયોગ કરો..." 
            className="min-h-[120px] text-lg p-4 bg-white"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <div className="absolute bottom-2 right-2">
             <Button 
              size="icon" 
              className={`rounded-full h-14 w-14 shadow-lg transition-all ${isRecording ? 'bg-red-500 animate-pulse hover:bg-red-600' : 'bg-accent hover:bg-accent/90'}`}
              onClick={toggleRecording}
            >
              {isRecording ? <Square className="w-6 h-6 text-white" /> : <Mic className="w-6 h-6 text-accent-foreground" />}
            </Button>
          </div>
        </div>

        <Button className="w-full py-6 text-lg" disabled={loading || !query} onClick={handleSend}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "ખેડૂત AI ને પૂછો"}
        </Button>

        {audioUrl && (
          <div className="flex flex-col items-center gap-4 p-6 bg-white rounded-xl border-2 border-accent/20 shadow-sm animate-in fade-in zoom-in duration-300">
            <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center shadow-inner">
              <Volume2 className="w-8 h-8 text-accent-foreground animate-bounce" />
            </div>
            <p className="text-center font-bold text-accent-foreground">AI જવાબ આપી રહ્યું છે...</p>
            <audio ref={audioRef} controls className="w-full h-10" src={audioUrl} autoPlay />
          </div>
        )}
      </CardContent>
    </Card>
  )
}
