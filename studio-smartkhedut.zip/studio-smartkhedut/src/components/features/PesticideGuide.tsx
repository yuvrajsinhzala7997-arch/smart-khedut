"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { aiPesticideGuideDiseaseDetection, type AIPesticideGuideDiseaseDetectionOutput } from "@/ai/flows/ai-pesticide-guide-disease-detection"
import { Bug, Camera, Loader2, Info, ShoppingBag } from "lucide-react"
import Image from "next/image"
import { PlaceHolderImages } from "@/lib/placeholder-images"

export function PesticideGuide() {
  const [cropName, setCropName] = useState("")
  const [image, setImage] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<AIPesticideGuideDiseaseDetectionOutput | null>(null)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const simulateCamera = () => {
    setImage(PlaceHolderImages[0].imageUrl)
  }

  const handleDetect = async () => {
    if (!image || !cropName) return
    setLoading(true)
    try {
      const output = await aiPesticideGuideDiseaseDetection({
        cropName,
        photoDataUri: image,
      })
      setResult(output)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center gap-2">
            <Bug className="w-6 h-6 text-primary" />
            રોગ ઓળખ અને જંતુનાશક માર્ગદર્શિકા
          </CardTitle>
          <CardDescription>રોગ અને સારવાર ઓળખવા માટે પાંદડાનો ફોટો અપલોડ કરો</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>પાકનું નામ</Label>
            <Input 
              placeholder="દા.ત. ટામેટા, બટાકા, ઘઉં..." 
              value={cropName}
              onChange={(e) => setCropName(e.target.value)}
            />
          </div>

          <div className="flex flex-col items-center justify-center border-2 border-dashed border-muted rounded-xl p-8 bg-muted/20 gap-4">
            {image ? (
              <div className="relative w-full aspect-square max-w-[300px] rounded-lg overflow-hidden border shadow-inner">
                <Image src={image} alt="Crop Leaf" fill className="object-cover" />
                <Button variant="destructive" size="sm" className="absolute top-2 right-2" onClick={() => setImage(null)}>દૂર કરો</Button>
              </div>
            ) : (
              <div className="text-center space-y-4">
                <Camera className="w-16 h-16 text-muted-foreground mx-auto" />
                <div className="flex gap-2 justify-center">
                  <Button variant="outline" onClick={() => document.getElementById('leaf-upload')?.click()}>ફોટો અપલોડ કરો</Button>
                  <Button variant="outline" onClick={simulateCamera}>નમૂનો જુઓ</Button>
                  <input id="leaf-upload" type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
                </div>
              </div>
            )}
          </div>

          <Button className="w-full py-6 text-lg" disabled={loading || !image || !cropName} onClick={handleDetect}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "રોગ શોધો"}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="text-xl text-primary font-headline flex items-center gap-2">
              <Info className="w-5 h-5" />
              AI વિશ્લેષણ પરિણામ
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between p-3 rounded-lg bg-white border">
              <span className="text-muted-foreground font-medium">ઓળખાયેલ રોગ:</span>
              <span className="font-bold text-red-600">{result.detectedDisease}</span>
            </div>
            <div className="flex justify-between p-3 rounded-lg bg-white border">
              <span className="text-muted-foreground font-medium">શ્રેષ્ઠ જંતુનાશક:</span>
              <span className="font-bold">{result.bestPesticide}</span>
            </div>
            <div className="flex justify-between p-3 rounded-lg bg-white border">
              <span className="text-muted-foreground font-medium">ભલામણ કરેલ ડોઝ:</span>
              <span className="font-bold">{result.dosage}</span>
            </div>
            <div className="flex justify-between p-3 rounded-lg bg-primary/10 border-primary/20">
              <span className="font-medium flex items-center gap-2"><ShoppingBag className="w-4 h-4" /> બજાર ભાવ:</span>
              <span className="font-bold text-primary">{result.marketPrice}</span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
