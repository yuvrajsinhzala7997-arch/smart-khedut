
"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CloudRain, CloudSun, Thermometer, Wind, AlertTriangle, MapPin, Loader2 } from "lucide-react"
import { useLanguage } from "@/context/LanguageContext"
import { trackLocation } from "@/lib/analytics"

export function WeatherWidget() {
  const { t, language } = useLanguage()
  const [locationName, setLocationName] = useState<string | null>(null)
  const [isDetecting, setIsDetecting] = useState(false)

  const defaultLocation = {
    en: "Surat, Gujarat",
    hi: "सूरत, गुजरात",
    gu: "સુરત, ગુજરાત"
  }

  const condition = {
    en: "Partly Cloudy",
    hi: "आंशिक रूप से बादल",
    gu: "થોડા વાદળછાયા"
  }

  const handleGetLocation = () => {
    if (!("geolocation" in navigator)) {
      alert("Geolocation is not supported by your browser")
      return
    }

    setIsDetecting(true)
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=10&addressdetails=1`
          )
          const data = await response.json()
          
          if (data.address) {
            const city = data.address.city || data.address.town || data.address.village || data.address.suburb || ""
            const state = data.address.state || ""
            const fullLocation = city && state ? `${city}, ${state}` : city || state || "Detected Location"
            setLocationName(fullLocation)
            
            // Track location in admin analytics
            trackLocation(fullLocation)
          } else {
            setLocationName("Location Found")
          }
        } catch (error) {
          console.error("Error reverse geocoding:", error)
          setLocationName(t('location_error'))
        } finally {
          setIsDetecting(false)
        }
      },
      (error) => {
        console.error("Error getting geolocation:", error)
        setIsDetecting(false)
        alert(t('location_error'))
      }
    )
  }

  return (
    <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-2xl font-bold font-headline">
                {locationName || (defaultLocation as any)[language]}
              </h3>
            </div>
            <p className="text-muted-foreground">{(condition as any)[language]}</p>
            <Button 
              variant="ghost" 
              size="sm" 
              className="mt-2 h-7 px-2 text-xs gap-1.5 text-primary hover:text-primary hover:bg-primary/5"
              onClick={handleGetLocation}
              disabled={isDetecting}
            >
              {isDetecting ? (
                <Loader2 className="w-3 h-3 animate-spin" />
              ) : (
                <MapPin className="w-3 h-3" />
              )}
              {isDetecting ? t('detecting') : t('use_location')}
            </Button>
          </div>
          <div className="text-4xl font-bold flex items-center gap-2">
            <CloudSun className="w-10 h-10 text-yellow-500" />
            32°C
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/50">
            <CloudRain className="w-5 h-5 text-blue-500 mb-1" />
            <span className="text-xs text-muted-foreground">{t('rain')}</span>
            <span className="font-semibold text-sm">10%</span>
          </div>
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/50">
            <Thermometer className="w-5 h-5 text-red-500 mb-1" />
            <span className="text-xs text-muted-foreground">{t('humidity')}</span>
            <span className="font-semibold text-sm">65%</span>
          </div>
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/50">
            <Wind className="w-5 h-5 text-green-500 mb-1" />
            <span className="text-xs text-muted-foreground">{t('wind')}</span>
            <span className="font-semibold text-sm">12 km/h</span>
          </div>
        </div>

        <div className="bg-yellow-100 border-l-4 border-yellow-500 p-3 rounded-r-md flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-yellow-700 shrink-0" />
          <p className="text-xs text-yellow-800">
            <strong>{language === 'en' ? 'Warning:' : language === 'hi' ? 'चेतावनी:' : 'ચેતવણી:'}</strong> {t('weather_alert_desc')}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
