"use client"

import { Sprout, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { LanguageSelector } from "@/components/LanguageSelector"
import { useLanguage } from "@/context/LanguageContext"

interface DashboardHeaderProps {
  onHome: () => void
}

export function DashboardHeader({ onHome }: DashboardHeaderProps) {
  const { t } = useLanguage()

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b z-50">
      <div className="container max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer group" 
          onClick={onHome}
        >
          <div className="bg-primary p-1.5 rounded-lg text-white group-hover:rotate-12 transition-transform">
            <Sprout className="w-6 h-6" />
          </div>
          <h1 className="font-headline text-xl font-bold text-primary tracking-tight">{t('app_title')}</h1>
        </div>
        
        <div className="flex items-center gap-2 sm:gap-4">
          <LanguageSelector />
          <Button variant="ghost" size="icon" className="rounded-full border border-border">
            <User className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </header>
  )
}
