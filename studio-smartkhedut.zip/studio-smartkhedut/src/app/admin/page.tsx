
"use client"

import { useState, useEffect } from "react"
import { auth, db } from "@/lib/firebase"
import { signInWithEmailAndPassword, onAuthStateChanged, signOut, User } from "firebase/auth"
import { collection, doc, onSnapshot, query, orderBy, limit } from "firebase/firestore"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { 
  LayoutDashboard, 
  Users, 
  MapPin, 
  TrendingUp, 
  LogOut, 
  Loader2,
  Lock,
  BarChart3,
  Info
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function AdminPage() {
  const [user, setUser] = useState<User | null>(null)
  const [email, setEmail] = useState("admin@smartkhedut.com")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(true)
  const [authLoading, setAuthLoading] = useState(false)
  
  const [stats, setStats] = useState<any>(null)
  const [locations, setLocations] = useState<any[]>([])
  const { toast } = useToast()

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser)
      setLoading(false)
    })
    return () => unsubscribe()
  }, [])

  useEffect(() => {
    if (user) {
      const unsubStats = onSnapshot(doc(db, 'analytics', 'features'), (doc) => {
        if (doc.exists()) setStats(doc.data())
      })

      const unsubLocations = onSnapshot(query(collection(db, 'locations'), orderBy('count', 'desc'), limit(10)), (snapshot) => {
        const locs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }))
        setLocations(locs)
      })

      return () => {
        unsubStats()
        unsubLocations()
      }
    }
  }, [user])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setAuthLoading(true)
    try {
      await signInWithEmailAndPassword(auth, email, password)
      toast({ title: "લોગિન સફળ", description: "એડમિન ડેશબોર્ડમાં આપનું સ્વાગત છે" })
    } catch (error: any) {
      toast({ 
        variant: "destructive", 
        title: "લોગિન નિષ્ફળ", 
        description: "કૃપા કરીને ઈમેલ અને પાસવર્ડ તપાસો. (ઈમેલ: admin@smartkhedut.com, પાસવર્ડ: admin123)" 
      })
    } finally {
      setAuthLoading(false)
    }
  }

  const handleLogout = () => signOut(auth)

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/20">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-muted/30 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl border-t-4 border-primary mb-6">
          <CardHeader className="text-center">
            <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit mb-4">
              <Lock className="w-8 h-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-headline font-bold">એડમિન લોગિન</CardTitle>
            <CardDescription>સ્માર્ટ ખેડૂત AI એડમિનિસ્ટ્રેટર માટે સુરક્ષિત પ્રવેશ</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">એડમિન ઈમેલ</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="admin@smartkhedut.com" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">પાસવર્ડ</Label>
                <Input 
                  id="password" 
                  type="password" 
                  placeholder="admin123"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full py-6 font-bold text-lg" disabled={authLoading}>
                {authLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : "લોગિન કરો"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Alert className="max-w-md bg-blue-50 border-blue-200">
          <Info className="h-4 w-4 text-blue-600" />
          <AlertTitle className="text-blue-800 font-bold">નોંધ (Prototyping Note)</AlertTitle>
          <AlertDescription className="text-blue-700 text-xs">
            લોગિન કરવા માટે, કૃપા કરીને ખાતરી કરો કે તમે તમારા Firebase Console માં <strong>admin@smartkhedut.com</strong> ઈમેલ અને <strong>admin123</strong> પાસવર્ડ સાથે યુઝર બનાવ્યો છે.
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted/20">
      <header className="bg-white border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-2">
          <LayoutDashboard className="w-6 h-6 text-primary" />
          <h1 className="text-xl font-bold font-headline text-primary">એડમિન ડેશબોર્ડ</h1>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-muted-foreground hidden sm:inline">{user.email}</span>
          <Button variant="outline" onClick={handleLogout} className="gap-2 border-primary/20 hover:bg-primary/5">
            <LogOut className="w-4 h-4" />
            લોગઆઉટ
          </Button>
        </div>
      </header>

      <main className="container max-w-6xl mx-auto p-6 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-br from-primary to-primary/80 text-white shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2 opacity-90">
                <Users className="w-4 h-4" />
                કુલ વપરાશ
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black">{stats?.totalInteractions || 0}</div>
              <p className="text-xs opacity-70 mt-1">એપ્લિકેશન સાથે કુલ આંતરક્રિયા</p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
                <TrendingUp className="w-4 h-4" />
                લોકપ્રિય સુવિધા
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary capitalize">
                {stats ? Object.entries(stats)
                  .filter(([k]) => !['totalInteractions', 'lastActive'].includes(k))
                  .sort(([, a]: any, [, b]: any) => b - a)[0]?.[0]?.replace(/_/g, ' ') || 'N/A' : 'લોડ થઈ રહ્યું છે...'}
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                સક્રિય વિસ્તારો
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{locations.length} લોકેશન</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="shadow-sm">
            <CardHeader className="border-b bg-muted/10">
              <CardTitle className="flex items-center gap-2 text-lg">
                <BarChart3 className="w-5 h-5 text-primary" />
                સુવિધાઓનો વપરાશ
              </CardTitle>
              <CardDescription>ખેડૂતો દ્વારા કઈ સેવાનો વધુ ઉપયોગ થાય છે તેનું વિશ્લેષણ</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {stats && Object.entries(stats)
                  .filter(([k]) => !['totalInteractions', 'lastActive'].includes(k))
                  .sort(([, a]: any, [, b]: any) => b - a)
                  .map(([name, count]: any) => (
                    <div key={name} className="flex items-center justify-between p-4 bg-muted/30 rounded-xl border border-border/50 hover:bg-muted/50 transition-colors">
                      <span className="font-bold capitalize text-sm">{name.replace(/_/g, ' ')}</span>
                      <span className="bg-primary text-white px-3 py-1 rounded-full text-xs font-black">{count}</span>
                    </div>
                  ))
                }
                {(!stats || Object.keys(stats).length <= 2) && (
                  <div className="text-center py-10 text-muted-foreground text-sm">હજુ સુધી કોઈ ડેટા નથી.</div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader className="border-b bg-muted/10">
              <CardTitle className="flex items-center gap-2 text-lg">
                <MapPin className="w-5 h-5 text-primary" />
                સક્રિય શહેરો/ગામો
              </CardTitle>
              <CardDescription>જ્યાંથી ખેડૂતો એપનો ઉપયોગ કરી રહ્યા છે</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {locations.length > 0 ? (
                  locations.map((loc) => (
                    <div key={loc.id} className="flex items-center justify-between p-4 border rounded-xl hover:border-primary/40 hover:bg-primary/5 transition-all">
                      <div>
                        <div className="font-bold text-sm">{loc.name}</div>
                        <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">
                          છેલ્લે જોયું: {loc.lastSeen?.toDate().toLocaleDateString()}
                        </div>
                      </div>
                      <div className="text-primary font-black text-lg">{loc.count}</div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-10 text-muted-foreground text-sm">કોઈ લોકેશન ડેટા મળ્યો નથી.</div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
