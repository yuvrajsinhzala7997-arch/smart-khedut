
"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/layout/DashboardHeader"
import { WeatherWidget } from "@/components/dashboard/WeatherWidget"
import { CropRecommendation } from "@/components/features/CropRecommendation"
import { FertilizerAdvisor } from "@/components/features/FertilizerAdvisor"
import { PesticideGuide } from "@/components/features/PesticideGuide"
import { MandiPrices } from "@/components/features/MandiPrices"
import { ProfitCalculator } from "@/components/features/ProfitCalculator"
import { VoiceAssistant } from "@/components/features/VoiceAssistant"
import { GovSchemes } from "@/components/features/GovSchemes"
import { CropCalendar } from "@/components/features/CropCalendar"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/context/LanguageContext"
import { trackFeatureUsage } from "@/lib/analytics"
import { 
  Sprout, 
  CloudSun, 
  FlaskConical, 
  Bug, 
  CircleDollarSign, 
  Calculator, 
  Bot, 
  Landmark, 
  Calendar,
  LayoutDashboard,
  Download
} from "lucide-react"

type Tab = "home" | "crop" | "fertilizer" | "pesticide" | "mandi" | "calculator" | "voice" | "schemes" | "calendar"

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>("home")
  const { t } = useLanguage()

  const handleTabChange = (tabId: Tab) => {
    setActiveTab(tabId)
    if (tabId !== "home") {
      trackFeatureUsage(tabId)
    }
  }

  const DashboardButtons = [
    { id: "crop", label: t('crop'), icon: Sprout, color: "bg-green-500" },
    { id: "fertilizer", label: t('fertilizer'), icon: FlaskConical, color: "bg-blue-500" },
    { id: "pesticide", label: t('pesticide'), icon: Bug, color: "bg-red-500" },
    { id: "mandi", label: t('mandi'), icon: CircleDollarSign, color: "bg-yellow-500" },
    { id: "calculator", label: t('calculator'), icon: Calculator, color: "bg-emerald-600" },
    { id: "voice", label: t('voice'), icon: Bot, color: "bg-purple-500" },
    { id: "calendar", label: t('calendar'), icon: Calendar, color: "bg-indigo-500" },
    { id: "schemes", label: t('schemes'), icon: Landmark, color: "bg-orange-500" },
  ]

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <DashboardHeader onHome={() => setActiveTab("home")} />

      <main className="container max-w-4xl mx-auto px-4 pt-20 pb-10">
        {activeTab === "home" && (
          <div className="space-y-8 animate-in fade-in duration-500">
            {/* APK Download Banner */}
            <div className="bg-primary/10 border border-primary/20 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="bg-primary p-3 rounded-xl text-white shadow-lg">
                  <Download className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg leading-tight">{t('download_apk')}</h3>
                  <p className="text-sm text-muted-foreground">{t('apk_desc')}</p>
                </div>
              </div>
              <Button 
                className="w-full md:w-auto font-bold gap-2 py-6 px-8 rounded-xl shadow-md"
                onClick={() => window.open('#', '_blank')}
              >
                <Download className="w-5 h-5" />
                {t('download_btn')}
              </Button>
            </div>

            <section>
              <h2 className="text-xl font-headline font-bold mb-4 flex items-center gap-2">
                <CloudSun className="w-5 h-5 text-primary" />
                {t('weather_alerts')}
              </h2>
              <WeatherWidget />
            </section>

            <section>
              <h2 className="text-xl font-headline font-bold mb-4 flex items-center gap-2">
                <LayoutDashboard className="w-5 h-5 text-primary" />
                {t('quick_services')}
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {DashboardButtons.map((btn) => (
                  <button
                    key={btn.id}
                    onClick={() => handleTabChange(btn.id as Tab)}
                    className="flex flex-col items-center justify-center p-4 rounded-2xl bg-white border border-border shadow-sm hover:shadow-md hover:border-primary transition-all active:scale-95 group text-center"
                  >
                    <div className={`${btn.color} p-3 rounded-full mb-3 text-white shadow-lg group-hover:scale-110 transition-transform`}>
                      <btn.icon className="w-6 h-6" />
                    </div>
                    <span className="font-bold text-sm block leading-tight">{btn.label}</span>
                  </button>
                ))}
              </div>
            </section>

            <section>
              <GovSchemes />
            </section>
          </div>
        )}

        {activeTab !== "home" && (
          <div className="animate-in slide-in-from-bottom-4 duration-400 space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Button variant="ghost" onClick={() => setActiveTab("home")} className="text-primary font-bold">← {t('back_home')}</Button>
            </div>
            
            {activeTab === "crop" && <CropRecommendation />}
            {activeTab === "fertilizer" && <FertilizerAdvisor />}
            {activeTab === "pesticide" && <PesticideGuide />}
            {activeTab === "mandi" && <MandiPrices />}
            {activeTab === "calculator" && <ProfitCalculator />}
            {activeTab === "voice" && <VoiceAssistant />}
            {activeTab === "calendar" && <CropCalendar />}
            {activeTab === "schemes" && (
              <div className="space-y-8">
                <GovSchemes />
              </div>
            )}
          </div>
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around items-center p-2 md:hidden z-50">
        <button onClick={() => setActiveTab("home")} className={`flex flex-col items-center p-1 ${activeTab === "home" ? "text-primary" : "text-muted-foreground"}`}>
          <LayoutDashboard className="w-6 h-6" />
          <span className="text-[10px] font-bold">{t('home')}</span>
        </button>
        <button onClick={() => handleTabChange("voice")} className={`flex flex-col items-center p-1 ${activeTab === "voice" ? "text-primary" : "text-muted-foreground"}`}>
          <Bot className="w-6 h-6" />
          <span className="text-[10px] font-bold">{t('voice')}</span>
        </button>
        <button onClick={() => handleTabChange("pesticide")} className={`flex flex-col items-center p-1 ${activeTab === "pesticide" ? "text-primary" : "text-muted-foreground"}`}>
          <Bug className="w-6 h-6" />
          <span className="text-[10px] font-bold">{t('pesticide')}</span>
        </button>
        <button onClick={() => handleTabChange("mandi")} className={`flex flex-col items-center p-1 ${activeTab === "mandi" ? "text-primary" : "text-muted-foreground"}`}>
          <CircleDollarSign className="w-6 h-6" />
          <span className="text-[10px] font-bold">{t('mandi')}</span>
        </button>
      </nav>
    </div>
  )
}
