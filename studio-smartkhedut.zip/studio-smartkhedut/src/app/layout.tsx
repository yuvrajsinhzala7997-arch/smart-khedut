import type {Metadata} from 'next';
import './globals.css';
import { LanguageProvider } from '@/context/LanguageContext';

export const metadata: Metadata = {
  title: 'Smart Khedut AI - Best Agriculture App for Gujarati Farmers',
  description: 'સ્માર્ટ ખેડૂત AI - ગુજરાતી ખેડૂતો માટે શ્રેષ્ઠ ખેતી એપ. પાક સૂચન, ખાતર સલાહ અને રોગ ઓળખ માટે AI ટેકનોલોજીનો ઉપયોગ કરો.',
  keywords: ['agriculture app', 'gujarati farmers', 'farming assistant', 'smart khedut ai', 'crop disease detection', 'mandi prices gujarat'],
  authors: [{ name: 'Smart Khedut Team' }],
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    title: 'Smart Khedut AI - Best Agriculture App for Gujarati Farmers',
    description: 'ગુજરાતી ખેડૂતો માટે ખાસ બનાવેલી AI આધારિત ખેતી એપ. આજે જ ડાઉનલોડ કરો.',
    type: 'website',
    locale: 'gu_IN',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="gu">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=PT+Sans:wght@400;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased bg-background text-foreground">
        <LanguageProvider>
          {children}
        </LanguageProvider>
      </body>
    </html>
  );
}
