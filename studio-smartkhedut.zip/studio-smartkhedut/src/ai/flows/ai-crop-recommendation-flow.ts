'use server';
/**
 * @fileOverview An AI agent that recommends crops based on farm details.
 *
 * - aiCropRecommendation - A function that handles the crop recommendation process.
 * - AiCropRecommendationInput - The input type for the aiCropRecommendation function.
 * - AiCropRecommendationOutput - The return type for the aiCropRecommendation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiCropRecommendationInputSchema = z.object({
  soilType: z.string().describe('The type of soil in the farm (e.g., "loamy", "sandy", "clay").'),
  season: z.string().describe('The current season for planting (e.g., "Kharif", "Rabi", "Summer").'),
  state: z.string().describe('The Indian state where the farm is located (e.g., "Gujarat", "Maharashtra").'),
  landSizeAcres: z.number().positive().describe('The size of the land in acres.'),
});
export type AiCropRecommendationInput = z.infer<typeof AiCropRecommendationInputSchema>;

const AiCropRecommendationOutputSchema = z.object({
  recommendedCrops: z.array(
    z.object({
      cropName: z.string().describe('The name of the recommended crop.'),
      expectedYieldKgPerAcre: z.number().positive().describe('The expected yield of the crop per acre in kilograms.'),
      estimatedProfitPerAcreINR: z.number().describe('The estimated profit per acre for the crop in Indian Rupees (INR).'),
      reasoning: z.string().describe('A brief explanation of why this crop is recommended given the input parameters.'),
    })
  ).describe('An array of recommended crops with their details.'),
});
export type AiCropRecommendationOutput = z.infer<typeof AiCropRecommendationOutputSchema>;

export async function aiCropRecommendation(input: AiCropRecommendationInput): Promise<AiCropRecommendationOutput> {
  return aiCropRecommendationFlow(input);
}

const aiCropRecommendationPrompt = ai.definePrompt({
  name: 'aiCropRecommendationPrompt',
  input: {schema: AiCropRecommendationInputSchema},
  output: {schema: AiCropRecommendationOutputSchema},
  prompt: `You are an expert agricultural advisor for Indian farmers. Based on the provided farm details, recommend the best crops to grow. For each recommended crop, provide the expected yield per acre, the estimated profit per acre, and a brief reasoning for the recommendation.

Consider the following details:
Soil Type: {{{soilType}}}
Season: {{{season}}}
State: {{{state}}}
Land Size (Acres): {{{landSizeAcres}}}

Please provide at least 3 distinct crop recommendations, or fewer if suitable options are limited for the given conditions. The output should be a JSON object conforming to the output schema.`,
});

const aiCropRecommendationFlow = ai.defineFlow(
  {
    name: 'aiCropRecommendationFlow',
    inputSchema: AiCropRecommendationInputSchema,
    outputSchema: AiCropRecommendationOutputSchema,
  },
  async input => {
    const {output} = await aiCropRecommendationPrompt(input);
    if (!output) {
      throw new Error('Failed to get crop recommendations.');
    }
    return output;
  }
);
