'use server';
/**
 * @fileOverview An AI Voice Assistant that converts text queries into audio responses.
 * It uses a Genkit prompt to generate a textual response to farming-related questions
 * in Gujarati, Hindi, or English, and then converts this text to speech.
 *
 * - aiVoiceAssistant - A function that handles the voice assistant interaction.
 * - AIVoiceAssistantInput - The input type for the aiVoiceAssistant function.
 * - AIVoiceAssistantOutput - The return type for the aiVoiceAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import wav from 'wav';

// Input Schema: The transcribed text query from the farmer.
const AIVoiceAssistantInputSchema = z
  .string()
  .describe(
    'The transcribed text query from the farmer in Gujarati, Hindi, or English.'
  );
export type AIVoiceAssistantInput = z.infer<
  typeof AIVoiceAssistantInputSchema
>;

// Output Schema: The audio response as a data URI.
const AIVoiceAssistantOutputSchema = z.object({
  media: z
    .string()
    .describe('Data URI of the audio response in WAV format (data:audio/wav;base64,...).'),
});
export type AIVoiceAssistantOutput = z.infer<
  typeof AIVoiceAssistantOutputSchema
>;

/**
 * Helper function to convert raw PCM audio buffer to WAV format (Base64 encoded).
 * This function is adapted from the Genkit TTS example.
 */
async function toWav(
  pcmData: Buffer,
  channels = 1,
  rate = 24000,
  sampleWidth = 2
): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    const bufs = [] as any[];
    writer.on('error', reject);
    writer.on('data', function (d) {
      bufs.push(d);
    });
    writer.on('end', function () {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}

// Define the Genkit prompt for generating the textual response.
const aiVoiceAssistantPrompt = ai.definePrompt({
  name: 'aiVoiceAssistantPrompt',
  input: {schema: AIVoiceAssistantInputSchema},
  output: {schema: z.string().describe('The textual response from the AI assistant.')},
  prompt: `You are Smart Khedut AI, an agriculture assistant designed for Indian farmers.\nYou provide information and guidance on farming practices, crop diseases, and market prices.\nDetect the language of the farmer's question (Gujarati, Hindi, or English) and respond clearly and concisely in the same language.\nDo not ask follow-up questions unless necessary for clarification.\nFarmer's Question: {{{input}}}`,
});

// Define the Genkit flow.
const aiVoiceAssistantFlow = ai.defineFlow(
  {
    name: 'aiVoiceAssistantFlow',
    inputSchema: AIVoiceAssistantInputSchema,
    outputSchema: AIVoiceAssistantOutputSchema,
  },
  async (inputQuery) => {
    // 1. Get textual response from the AI assistant
    const {output: llmResponseText} = await aiVoiceAssistantPrompt(inputQuery);

    if (!llmResponseText) {
      throw new Error('Failed to get a textual response from the AI assistant.');
    }

    // 2. Convert the textual response to speech
    const {media} = await ai.generate({
      model: ai.googleAI.model('gemini-2.5-flash-preview-tts'),
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {voiceName: 'Algenib'},
          },
        },
      },
      prompt: llmResponseText,
    });

    if (!media) {
      throw new Error('Failed to generate audio from the textual response.');
    }

    // The media.url from TTS is 'data:audio/x-pcm;base64,...' (raw PCM)
    const audioBuffer = Buffer.from(
      media.url.substring(media.url.indexOf(',') + 1),
      'base64'
    );

    // 3. Convert PCM audio to WAV format
    const wavBase64 = await toWav(audioBuffer);

    return {
      media: 'data:audio/wav;base64,' + wavBase64,
    };
  }
);

/**
 * Provides an AI Voice Assistant feature that processes a text query (from speech-to-text)
 * and returns an audio response.
 * @param input The farmer's transcribed question.
 * @returns An object containing the audio response as a base64-encoded WAV data URI.
 */
export async function aiVoiceAssistant(
  input: AIVoiceAssistantInput
): Promise<AIVoiceAssistantOutput> {
  return aiVoiceAssistantFlow(input);
}
