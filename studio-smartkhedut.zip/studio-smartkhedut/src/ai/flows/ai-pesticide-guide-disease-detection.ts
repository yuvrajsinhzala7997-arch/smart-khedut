'use server';
/**
 * @fileOverview An AI agent for detecting plant diseases from photos and recommending pesticides.
 *
 * - aiPesticideGuideDiseaseDetection - A function that handles plant disease detection and pesticide recommendation.
 * - AIPesticideGuideDiseaseDetectionInput - The input type for the aiPesticideGuideDiseaseDetection function.
 * - AIPesticideGuideDiseaseDetectionOutput - The return type for the aiPesticideGuideDiseaseDetection function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIPesticideGuideDiseaseDetectionInputSchema = z.object({
  cropName: z.string().describe('The name of the crop the plant belongs to.'),
  photoDataUri: z
    .string()
    .describe(
      "A photo of a diseased plant, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AIPesticideGuideDiseaseDetectionInput = z.infer<
  typeof AIPesticideGuideDiseaseDetectionInputSchema
>;

const AIPesticideGuideDiseaseDetectionOutputSchema = z.object({
  detectedDisease: z
    .string()
    .describe('The name of the detected plant disease.'),
  bestPesticide: z
    .string()
    .describe('The recommended pesticide to treat the disease.'),
  dosage: z
    .string()
    .describe('The recommended dosage for the pesticide (e.g., "10ml per liter of water").'),
  marketPrice: z
    .string()
    .describe('An estimated market price for the recommended pesticide in India (e.g., "₹500 per bottle").'),
});
export type AIPesticideGuideDiseaseDetectionOutput = z.infer<
  typeof AIPesticideGuideDiseaseDetectionOutputSchema
>;

export async function aiPesticideGuideDiseaseDetection(
  input: AIPesticideGuideDiseaseDetectionInput
): Promise<AIPesticideGuideDiseaseDetectionOutput> {
  return aiPesticideGuideDiseaseDetectionFlow(input);
}

const detectDiseaseAndRecommendPesticidePrompt = ai.definePrompt({
  name: 'detectDiseaseAndRecommendPesticidePrompt',
  input: {schema: AIPesticideGuideDiseaseDetectionInputSchema},
  output: {schema: AIPesticideGuideDiseaseDetectionOutputSchema},
  prompt: `You are an expert agricultural assistant specializing in plant disease diagnosis and pesticide recommendations for Indian farmers.
Based on the provided image of the plant and its crop type, perform the following tasks:
1. Identify the specific plant disease affecting the plant.
2. Suggest the single best pesticide to treat this disease.
3. Provide the recommended dosage for the suggested pesticide.
4. Estimate the market price for this pesticide, specifically for the Indian market.

Crop: {{{cropName}}}
Plant Photo: {{media url=photoDataUri}}`,
});

const aiPesticideGuideDiseaseDetectionFlow = ai.defineFlow(
  {
    name: 'aiPesticideGuideDiseaseDetectionFlow',
    inputSchema: AIPesticideGuideDiseaseDetectionInputSchema,
    outputSchema: AIPesticideGuideDiseaseDetectionOutputSchema,
  },
  async input => {
    const {output} = await detectDiseaseAndRecommendPesticidePrompt(input);
    if (!output) {
      throw new Error('Failed to get pesticide recommendations from AI.');
    }
    return output;
  }
);
