'use server';
/**
 * @fileOverview An AI agent that provides fertilizer recommendations for a specified crop.
 *
 * - aiFertilizerAdvisor - A function that provides fertilizer recommendations.
 * - AIFertilizerAdvisorInput - The input type for the aiFertilizerAdvisor function.
 * - AIFertilizerAdvisorOutput - The return type for the aiFertilizerAdvisor function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIFertilizerAdvisorInputSchema = z.object({
  cropName: z
    .string()
    .describe('The name of the crop for which fertilizer advice is needed.'),
});
export type AIFertilizerAdvisorInput = z.infer<
  typeof AIFertilizerAdvisorInputSchema
>;

const AIFertilizerAdvisorOutputSchema = z.object({
  fertilizerName: z.string().describe('The recommended fertilizer name.'),
  quantityPerAcre: z
    .string()
    .describe(
      'The recommended quantity of fertilizer per acre, including units (e.g., "50 kg/acre").'
    ),
  applicationTime: z
    .string()
    .describe(
      'The best time to apply the fertilizer (e.g., "during seedling stage", "pre-sowing").'
    ),
  estimatedCost: z
    .string()
    .describe(
      'The estimated cost of the recommended fertilizer per acre, including currency (e.g., "₹ 1500 per acre").'
    ),
});
export type AIFertilizerAdvisorOutput = z.infer<
  typeof AIFertilizerAdvisorOutputSchema
>;

export async function aiFertilizerAdvisor(
  input: AIFertilizerAdvisorInput
): Promise<AIFertilizerAdvisorOutput> {
  return aiFertilizerAdvisorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'fertilizerAdvisorPrompt',
  input: {schema: AIFertilizerAdvisorInputSchema},
  output: {schema: AIFertilizerAdvisorOutputSchema},
  prompt: `You are an expert agricultural advisor specializing in fertilizer recommendations for crops grown in India.\n\nProvide detailed fertilizer advice for the crop: {{{cropName}}}.\nBased on the crop, suggest the optimal fertilizer name, the quantity needed per acre, the best time to apply it, and an estimated cost per acre.\nEnsure the quantity includes units and the cost includes currency.`,
});

const aiFertilizerAdvisorFlow = ai.defineFlow(
  {
    name: 'aiFertilizerAdvisorFlow',
    inputSchema: AIFertilizerAdvisorInputSchema,
    outputSchema: AIFertilizerAdvisorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
