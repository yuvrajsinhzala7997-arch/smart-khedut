import { config } from 'dotenv';
config();

import '@/ai/flows/ai-fertilizer-advisor.ts';
import '@/ai/flows/ai-pesticide-guide-disease-detection.ts';
import '@/ai/flows/ai-crop-recommendation-flow.ts';
import '@/ai/flows/ai-voice-assistant-flow.ts';