
"use client"

import React, { createContext, useContext, useState, ReactNode } from "react"

export type Language = "en" | "hi" | "gu"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const translations = {
  en: {
    app_title: "Smart Khedut AI",
    home: "Home",
    crop: "Crop Suggestion",
    fertilizer: "Fertilizer Advice",
    pesticide: "Disease/Pest",
    mandi: "Mandi Prices",
    calculator: "Profit Calculator",
    voice: "AI Assistant",
    calendar: "Schedule",
    schemes: "Gov Schemes",
    back_home: "Back to Home",
    weather_alerts: "Weather & Alerts",
    quick_services: "Quick Services",
    humidity: "Humidity",
    wind: "Wind",
    rain: "Rain",
    weather_alert_desc: "Alert: Scattered rain expected tomorrow morning. Plan sowing accordingly.",
    select_language: "Select Language",
    get_recommendations: "Get Recommendations",
    get_advice: "Get Advice",
    detect_disease: "Detect Disease",
    soil_type: "Soil Type",
    season: "Season",
    state: "State",
    land_size: "Land Size (Acres)",
    expected_yield: "Expected Yield",
    estimated_profit: "Estimated Profit",
    quantity: "Quantity",
    time: "Time",
    estimated_cost: "Estimated Cost",
    market_price: "Market Price",
    crop_name_placeholder: "e.g. Wheat, Cotton, Rice...",
    detected_disease: "Detected Disease",
    best_pesticide: "Best Pesticide",
    dosage: "Recommended Dosage",
    upload_photo: "Upload Photo",
    see_sample: "See Sample",
    remove: "Remove",
    calculate: "Calculate",
    total_cost: "Total Cost",
    total_income: "Total Income",
    net_profit: "Net Profit",
    profit_margin: "Profit Margin",
    ask_ai: "Ask Farmer AI",
    ai_responding: "AI is responding...",
    current_mandi_prices: "Current Mandi Prices",
    live_update: "Live Update",
    crop_col: "Crop",
    mandi_col: "Mandi",
    price_col: "Price (per Quintal)",
    trend_col: "Trend",
    use_location: "Use My Location",
    detecting: "Detecting...",
    location_error: "Location Error",
    download_apk: "Download Mobile App",
    apk_desc: "Get Smart Khedut AI directly on your phone",
    download_btn: "Download APK"
  },
  hi: {
    app_title: "स्मार्ट खेदूत AI",
    home: "होम",
    crop: "फसल सुझाव",
    fertilizer: "खाद सलाह",
    pesticide: "रोग/कीट",
    mandi: "मंडी भाव",
    calculator: "लाभ कैलकुलेटर",
    voice: "AI सहायक",
    calendar: "समय सारिणी",
    schemes: "सरकारी योजनाएं",
    back_home: "होम पर वापस जाएं",
    weather_alerts: "मौसम और अलर्ट",
    quick_services: "त्वरित सेवाएं",
    humidity: "नमी",
    wind: "हवा",
    rain: "बारिश",
    weather_alert_desc: "चेतावनी: कल सुबह छिटपुट बारिश की संभावना है। तदनुसार बुवाई की योजना बनाएं।",
    select_language: "भाषा चुनें",
    get_recommendations: "सिफारिशें प्राप्त करें",
    get_advice: "सलाह प्राप्त करें",
    detect_disease: "रोग का पता लगाएं",
    soil_type: "मिट्टी का प्रकार",
    season: "सीजन",
    state: "राज्य",
    land_size: "भूमि का आकार (एकड़)",
    expected_yield: "अपेक्षित उपज",
    estimated_profit: "अनुमानित लाभ",
    quantity: "मात्रा",
    time: "समय",
    estimated_cost: "अनुमानित लागत",
    market_price: "बाज़ार भाव",
    crop_name_placeholder: "जैसे: गेहूं, कपास, धान...",
    detected_disease: "पता चला रोग",
    best_pesticide: "सर्वश्रेष्ठ कीटनाशक",
    dosage: "अनुशंसित खुराक",
    upload_photo: "फोटो अपलोड करें",
    see_sample: "नमूना देखें",
    remove: "हटाएं",
    calculate: "गणना करें",
    total_cost: "कुल लागत",
    total_income: "कुल आय",
    net_profit: "शुद्ध लाभ",
    profit_margin: "लाभ मार्जिन",
    ask_ai: "किसान AI से पूछें",
    ai_responding: "AI जवाब दे रहा है...",
    current_mandi_prices: "वर्तमान मंडी भाव",
    live_update: "लाइव अपडेट",
    crop_col: "फसल",
    mandi_col: "मंडी",
    price_col: "भाव (प्रति क्विंटल)",
    trend_col: "रुझान",
    use_location: "मेरी स्थिति का उपयोग करें",
    detecting: "पता लगाया जा रहा है...",
    location_error: "स्थान त्रुटि",
    download_apk: "मोबाइल ऐप डाउनलोड करें",
    apk_desc: "स्मार्ट खेदૂત AI सीधे अपने फोन पर प्राप्त करें",
    download_btn: "APK डाउनलोड करें"
  },
  gu: {
    app_title: "સ્માર્ટ ખેડૂત AI",
    home: "હોમ",
    crop: "પાક સૂચન",
    fertilizer: "ખાતર સલાહ",
    pesticide: "રોગ/જીવાત",
    mandi: "મંડી ભાવ",
    calculator: "નફાની ગણતરી",
    voice: "AI મદદનીશ",
    calendar: "સમયપત્રક",
    schemes: "સરકારી યોજના",
    back_home: "હોમ પર પાછા જાઓ",
    weather_alerts: "હવામાન અને એલર્ટ્સ",
    quick_services: "ઝડપી સેવાઓ",
    humidity: "ભેજ",
    wind: "પવન",
    rain: "વરસાદ",
    weather_alert_desc: "ચેતવણી: આવતીકાલે સવારે છૂટોછવાયો વરસાદ પડવાની શક્યતા છે. તે મુજબ વાવણીનું આયોજન કરો.",
    select_language: "ભાષા પસંદ કરો",
    get_recommendations: "ભલામણો મેળવો",
    get_advice: "સલાહ મેળવો",
    detect_disease: "રોગ શોધો",
    soil_type: "જમીનનો પ્રકાર",
    season: "ઋતુ",
    state: "રાજ્ય",
    land_size: "જમીનનું કદ (એકર)",
    expected_yield: "અપેક્ષિત ઉપજ",
    estimated_profit: "અંદાજિત નફો",
    quantity: "જથ્થો",
    time: "સમય",
    estimated_cost: "અંદાજિત કિંમત",
    market_price: "બજાર ભાવ",
    crop_name_placeholder: "દા.ત. ઘઉં, કપાસ, ડાંગર...",
    detected_disease: "ઓળખાયેલ રોગ",
    best_pesticide: "શ્રેષ્ઠ જંતુનાશક",
    dosage: "ભલામણ કરેલ ડોઝ",
    upload_photo: "ફોટો અપલોડ કરો",
    see_sample: "નમૂનો જુઓ",
    remove: "દૂર કરો",
    calculate: "ગણતરી કરો",
    total_cost: "કુલ ખર્ચ",
    total_income: "કુલ આવક",
    net_profit: "ચોખ્ખો નફો",
    profit_margin: "નફાનો ગાળો",
    ask_ai: "ખેડૂત AI ને પૂછો",
    ai_responding: "AI જવાબ આપી રહ્યું છે...",
    current_mandi_prices: "માર્કેટ યાર્ડના ભાવ",
    live_update: "લાઇવ અપડેટ",
    crop_col: "પાક",
    mandi_col: "માર્કેટ યાર્ડ",
    price_col: "ભાવ (પ્રતિ ક્વિન્ટલ)",
    trend_col: "વલણ",
    use_location: "મારું સ્થાન વાપરો",
    detecting: "શોધાઈ રહ્યું છે...",
    location_error: "સ્થાનમાં ભૂલ",
    download_apk: "મોબાઈલ એપ ડાઉનલોડ કરો",
    apk_desc: "સ્માર્ટ ખેડૂત AI સીધું તમારા ફોનમાં મેળવો",
    download_btn: "APK ડાઉનલોડ કરો"
  }
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("gu")

  const t = (key: string): string => {
    return (translations[language] as any)[key] || key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
