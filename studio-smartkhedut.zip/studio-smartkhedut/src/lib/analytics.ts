
import { db } from './firebase';
import { doc, setDoc, increment, serverTimestamp } from 'firebase/firestore';

export async function trackFeatureUsage(featureName: string) {
  try {
    const statsRef = doc(db, 'analytics', 'features');
    await setDoc(statsRef, {
      [featureName]: increment(1),
      totalInteractions: increment(1),
      lastActive: serverTimestamp()
    }, { merge: true });
  } catch (error) {
    console.error("Error tracking feature:", error);
  }
}

export async function trackLocation(locationName: string) {
  try {
    const cityId = locationName.toLowerCase().replace(/[^a-z0-9]/g, '_');
    const locationRef = doc(db, 'locations', cityId);
    await setDoc(locationRef, {
      name: locationName,
      count: increment(1),
      lastSeen: serverTimestamp()
    }, { merge: true });

    // Also update global user counter (approximate)
    const globalRef = doc(db, 'analytics', 'users');
    await setDoc(globalRef, {
      totalCheckins: increment(1)
    }, { merge: true });
  } catch (error) {
    console.error("Error tracking location:", error);
  }
}
