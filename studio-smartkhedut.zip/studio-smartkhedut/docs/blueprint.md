# **App Name**: Smart Khedut AI

## Core Features:

- AI Crop Recommendation: Farmers input soil type, season, state, and land size. The AI tool recommends the best crops, expected yield, and estimated profit.
- AI Fertilizer Advisor: Based on the selected crop, the AI tool suggests the optimal fertilizer name, quantity per acre, best application time, and estimated cost.
- AI Pesticide Guide & Disease Detection: Farmers can upload a plant photo for AI-powered disease detection, then receive recommendations for the best pesticide, dosage, and market price.
- Weather Prediction: Provides essential weather data including rain forecast, temperature, humidity, and storm alerts for planning farm activities.
- Mandi Market Prices: Displays real-time market prices of various crops in Indian mandis to help farmers make informed selling decisions.
- Crop Calendar: A dynamic calendar displaying personalized sowing dates, irrigation schedules, fertilizer application times, and harvest predictions for selected crops.
- AI Voice Assistant: Farmers can interact with the app using a voice assistant, asking questions in Gujarati or Hindi for instant information and guidance.

## Style Guidelines:

- Primary color: A vibrant, fresh green (#81B814) symbolizing growth and agriculture, chosen for its energetic yet natural feel in a light theme.
- Background color: A subtle, desaturated off-white green (#F3F5F0) to provide a clean and airy canvas that enhances readability and keeps the focus on content.
- Accent color: A brighter, lively yellow-green (#69E052) used for calls to action, important notifications, and highlighting key interactive elements.
- Headline font: 'PT Sans', a humanist sans-serif, offering a blend of modernity and warmth, highly legible for headings and larger text.
- Body font: 'Inter', a clean, objective grotesque sans-serif for optimal readability of extensive information and data displays.
- Use clear, intuitive, and bold agricultural-themed icons that are easily recognizable and can be effectively scaled for 'big buttons'.
- A mobile-first, simple dashboard design featuring clear, generously sized interactive elements and cards to display information accessibly to farmers.
- Subtle and quick feedback animations for interactions like button taps, data loading, and AI recommendation generation, enhancing usability without distraction.